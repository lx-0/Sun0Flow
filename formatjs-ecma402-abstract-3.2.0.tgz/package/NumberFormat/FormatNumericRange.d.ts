import type { Decimal } from "@formatjs/bigdecimal";
import { type NumberFormatInternal } from "../types/number.js";
/**
* https://tc39.es/ecma402/#sec-formatnumericrange
*/
export declare function FormatNumericRange(numberFormat: Intl.NumberFormat, x: Decimal, y: Decimal, { getInternalSlots }: {
	getInternalSlots(nf: Intl.NumberFormat): NumberFormatInternal;
}): string;
