import type { Decimal } from "@formatjs/bigdecimal";
import { type NumberFormatInternal, type NumberFormatPart } from "../types/number.js";
/**
* https://tc39.es/ecma402/#sec-partitionnumberpattern
*/
export declare function PartitionNumberPattern(internalSlots: NumberFormatInternal, _x: Decimal): NumberFormatPart[];
