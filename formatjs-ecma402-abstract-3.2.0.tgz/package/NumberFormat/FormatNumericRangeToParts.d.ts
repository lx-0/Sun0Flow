import type { Decimal } from "@formatjs/bigdecimal";
import { type NumberFormatInternal, type NumberRangeToParts } from "../types/number.js";
/**
* https://tc39.es/ecma402/#sec-formatnumericrangetoparts
*/
export declare function FormatNumericRangeToParts(numberFormat: Intl.NumberFormat, x: Decimal, y: Decimal, { getInternalSlots }: {
	getInternalSlots(nf: Intl.NumberFormat): NumberFormatInternal;
}): NumberRangeToParts[];
