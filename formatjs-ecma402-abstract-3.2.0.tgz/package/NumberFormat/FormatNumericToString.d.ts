import type { Decimal } from "@formatjs/bigdecimal";
import { type NumberFormatDigitInternalSlots } from "../types/number.js";
/**
* https://tc39.es/ecma402/#sec-formatnumberstring
*/
export declare function FormatNumericToString(intlObject: Pick<NumberFormatDigitInternalSlots, "roundingType" | "minimumSignificantDigits" | "maximumSignificantDigits" | "minimumIntegerDigits" | "minimumFractionDigits" | "maximumFractionDigits" | "roundingIncrement" | "roundingMode" | "trailingZeroDisplay">, _x: Decimal): {
	roundedNumber: Decimal;
	formattedString: string;
};
